export default function Work() {
    return (
      <section className="w-full max-w-6xl mx-auto px-6 py-16">
      <h2 className="text-4xl font-bold mb-10">Selected Work</h2>

      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((project, idx) => (
          <div
            key={idx}
            className="bg-white dark:bg-espresso-surface border border-gray-200 dark:border-espresso-border p-6 rounded-xl shadow-sm transition-all duration-300 hover:shadow-md hover:scale-[1.01]"
          >
            <h3 className="text-xl font-semibold mb-2 text-black dark:text-espresso-text">
              {project.title}
            </h3>
            <p className="text-sm text-gray-700 dark:text-espresso-muted">
              {project.description}
            </p>
          </div>
        ))}
      </div>
    </section>
    );
  }