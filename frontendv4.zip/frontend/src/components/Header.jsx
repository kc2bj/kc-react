export default function Header() {
  return (
    <header className="w-full px-8 py-4 dark:bg-espresso-bg dark:text-espresso-text transition-colors duration-300">
    </header>
  );
}
