import { useState } from "react";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="w-full py-6 px-4">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
      <div className="bg-red-500 sm:bg-green-500 h-20 w-full">
  Resize me: should be red on mobile, green on sm+
</div>

        {/* Left side: logo or site name */}
        <h1 className="text-lg font-semibold">Kris Celeste</h1>

        {/* Desktop pills */}
        <ul className="hidden sm:flex gap-4 bg-neutral-100 text-neutral-800 rounded-full px-6 py-2 shadow-md text-sm">
          <li><a href="#" className="px-3 py-1 rounded-full hover:bg-neutral-200 transition">About</a></li>
          <li><a href="#" className="px-3 py-1 rounded-full hover:bg-neutral-200 transition">Articles</a></li>
          <li><a href="#" className="px-3 py-1 rounded-full hover:bg-neutral-200 transition">Projects</a></li>
          <li><a href="#" className="px-3 py-1 rounded-full hover:bg-neutral-200 transition">Speaking</a></li>
          <li><a href="#" className="px-3 py-1 rounded-full hover:bg-neutral-200 transition">Uses</a></li>
        </ul>

        {/* Hamburger toggle (mobile only) */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="sm:hidden p-2 rounded-md hover:bg-neutral-200 transition"
          aria-label="Toggle navigation"
        >
          {isOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile dropdown menu */}
      {isOpen && (
        <div className="sm:hidden mt-4">
          <ul className="flex flex-col gap-2 text-sm font-medium bg-neutral-100 p-4 rounded-lg shadow">
            <li><a href="#" className="block px-3 py-2 rounded-md hover:bg-neutral-200 transition">About</a></li>
            <li><a href="#" className="block px-3 py-2 rounded-md hover:bg-neutral-200 transition">Articles</a></li>
            <li><a href="#" className="block px-3 py-2 rounded-md hover:bg-neutral-200 transition">Projects</a></li>
            <li><a href="#" className="block px-3 py-2 rounded-md hover:bg-neutral-200 transition">Speaking</a></li>
            <li><a href="#" className="block px-3 py-2 rounded-md hover:bg-neutral-200 transition">Uses</a></li>
          </ul>
        </div>
      )}
    </nav>
  );
}
