export default function Header() {
  return (
    <header className="w-full border-b border-gray-200 px-8 py-4 ml-64">
      <h2 className="text-xl font-semibold">Welcome!</h2>
    </header>
  );
}
