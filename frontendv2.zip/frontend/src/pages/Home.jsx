export default function Home() {
  return (
    <section className="space-y-4">
      <h1 className="text-4xl font-bold font-sans bg-red-500 sm:bg-green-500 text-white p-4 rounded">
        Tailwind is working
      </h1>
      <p className="text-gray-600">
        Resize your screen to see the color change.
      </p>
    </section>
  );
}
