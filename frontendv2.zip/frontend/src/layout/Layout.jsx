import Navigation from '../components/Navigation';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Outlet } from 'react-router-dom';

export default function Layout() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <Header />
      <main className="flex-1 px-6 max-w-4xl mx-auto py-10">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
